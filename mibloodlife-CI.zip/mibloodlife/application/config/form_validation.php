<?php

$config = [
    'login' => [
        [
            'field' => 'email', 'label' => 'Email', 'rules' => 'required'
        ],
        [
            'field' => 'password', 'label' => 'Password', 'rules' => 'required'
        ]
    ],
    'unique_user' => [
        [
            'field' => 'email', 'label' => 'Email', 'rules' => 'required|valid_email|is_unique[users.email]'
        ]
    ]
];
