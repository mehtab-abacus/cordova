<?php
/* Email configurations */

return $config = [
    'protocol'  => 'smtp',
    'smtp_host' => 'ssl://mail.questdesk.net',
    'smtp_port' => 465,
    'smtp_user' => 'rajat@questdesk.net',
    'smtp_pass' => 'yq)5tPNwgq;G',
    'smtp_timeout'  => 5,
    'mailtype'  => 'html',
    'charset'   => 'iso-8859-1'
];