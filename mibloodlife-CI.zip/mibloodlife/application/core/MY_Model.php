<?php defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Model extends CI_Model
{
    const FROM_MAIL = 'fbddonorsclub@gmail.com';
    const FROM_NAME = 'MIBloodLife';

    public function __construct()
    {
        parent::__construct();
    }
}