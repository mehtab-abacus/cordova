<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Donor extends MY_Model
{
    public function save($data, $status)
    {
        $this->db->set('created_at', 'NOW()', FALSE);
        $this->db->insert('donors', ['name' => $data['name'], 'age' => $data['age'], 'blood_group_id' => $data['blood_group'], 'mobile' => $data['mobile'], 'email' => $data['email'], 'address' => $data['address'], 'status' => $status]);
        return $this->db->insert_id();
    }

    public function getDonor($donorId)
    {
        return $this->db->select('name, age, email, mobile, address, blood_group')
            ->join('blood_groups', 'donors.blood_group_id = blood_groups.id')
            ->where('donors.id', $donorId)->from('donors')->get()->row();
    }

    public function mailDonor($data)
    {
        $body = $this->load->view('emails/donor', compact('data'), true);
        $this->load->library('email');
        return $this->email->set_newline("\r\n")
            ->from(self::FROM_MAIL, self::FROM_NAME)->to($data->email)
            ->subject('Your request received - MIBloodLife')->message($body)->send();
    }

    public function mailAdmin($data)
    {
        $body = $this->load->view('emails/donor-admin', compact('data'), true);
        $this->load->library('email');
        return $this->email->set_newline("\r\n")
            ->from(self::FROM_MAIL, self::FROM_NAME)->to(self::FROM_MAIL)
            ->subject('Donor mail by MiBloodLife')->message($body)->send();
    }
}