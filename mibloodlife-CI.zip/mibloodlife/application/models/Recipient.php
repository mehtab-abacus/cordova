<?php defined('BASEPATH') OR exit('No direct script access allowed');

Class Recipient extends MY_Model
{
    public function save($data, $status)
    {
        $this->db->set('created_at', 'NOW()', FALSE);
        $this->db->insert('recipients', ['name' => $data['name'], 'age' => $data['age'], 'component' => $data['component'], 'blood_group_id' => $data['blood_group'], 'units' => $data['units'], 'mobile' => $data['mobile'], 'email' => $data['email'], 'hospital' => $data['hospital'], 'address' => $data['address'], 'status' => $status]);
        return $this->db->insert_id();
    }

    public function getRecipient($recipientId)
    {
        return $this->db->select('name, age, email, mobile, component, units, hospital, address, blood_group')
            ->join('blood_groups', 'recipients.blood_group_id = blood_groups.id')
            ->where('recipients.id', $recipientId)->from('recipients')->get()->row();
    }

    public function mailRecipient($data)
    {
        $body = $this->load->view('emails/recipient', compact('data'), true);
        $this->load->library('email');
        return $this->email->set_newline("\r\n")
            ->from(self::FROM_MAIL, self::FROM_NAME)->to($data->email)
            ->subject('Your request received - MIBloodLife')->message($body)->send();
    }

    public function mailAdmin($data)
    {
        $body = $this->load->view('emails/recipient-admin', compact('data'), true);
        $this->load->library('email');
        return $this->email->set_newline("\r\n")
            ->from(self::FROM_MAIL, self::FROM_NAME)->to(self::FROM_MAIL)
            ->subject('Requirement mail by MiBloodLife')->message($body)->send();
    }
}