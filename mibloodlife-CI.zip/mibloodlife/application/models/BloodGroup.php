<?php defined('BASEPATH') OR exit('No direct script access allowed');

class BloodGroup extends MY_Model
{
    public function getBloodGroups($status)
    {
        return $this->db->select('id, blood_group')->where('status', $status)->from('blood_groups')->get()->result();
    }
}