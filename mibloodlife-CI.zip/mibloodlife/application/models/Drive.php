<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Drive extends MY_Model
{
    public function save($data, $status)
    {
        $this->db->set('created_at', 'NOW()', FALSE);
        $this->db->insert('drives', ['name' => $data['name'], 'organization' => $data['organization'], 'address' => $data['address'], 'drive_date' => date('Y-m-d', strtotime(str_replace('-', '/', $data['drive_date']))), 'description' => $data['description'], 'status' => $status]);
        return $this->db->insert_id();
    }

    public function getDrive($driveId)
    {
        return $this->db->select('name, organization, address, drive_date, description')
            ->where('id', $driveId)->from('drives')->get()->row();
    }

    public function mailAdmin($data)
    {
        $body = $this->load->view('emails/book-drive-admin', compact('data'), true);
        $this->load->library('email');
        return $this->email->set_newline("\r\n")
            ->from(self::FROM_MAIL, self::FROM_NAME)->to(self::FROM_MAIL)
            ->subject('Drive mail by MiBloodLife')->message($body)->send();
    }
}