<?php defined('BASEPATH') OR exit('No direct script access allowed');

if(! function_exists('setViewMessage')) {
    function setFlashMessage($message, $message_class)
    {
        $ci =& get_instance();
        $ci->session->set_flashdata('message', $message);
        $ci->session->set_flashdata('message_class', $message_class);
    }
}

if (! function_exists('formatDT')) {
    function formatDT($value, $format = 'd-m-Y h:i A')
    {
        if(strtotime($value) && $value != '0000-00-00 00:00:00') return date($format, strtotime($value));
        else return '';
    }
}

if (! function_exists('paginate')) {
    function paginate($limit, $totalRows, $baseUrl, $suffix = '')
    {
        $ci =& get_instance();
        $ci->load->library('pagination');
        $config = [
            'base_url' => $baseUrl,
            'total_rows' => $totalRows,
            'per_page' => $limit,
            'suffix' => $suffix,
            'first_tag_open' => "<li>",
            'first_tag_close' => "</li>",
            'last_tag_open' => "<li>",
            'last_tag_close' => "</li>",
            'full_tag_open' => "<ul class='pagination'>",
            'full_tag_close' => "</ul>",
            'next_tag_open' => "<li>",
            'next_tag_close' => "</li>",
            'prev_tag_open' => "<li>",
            'prev_tag_close' => "</li>",
            'num_tag_open' => "<li>",
            'num_tag_close' => "</li>",
            'cur_tag_open' => "<li class='active'><a>",
            'cur_tag_close' => "</a></li>",
        ];
        $ci->pagination->initialize($config);
    }
}

if (! function_exists('show_403')) {
    function show_403()
    {
        show_error('You do not have permission to view this directory or page using the credentials that you supplied.', 403, 'Forbidden: Access is denied.');
    }
}

if (! function_exists('dd')) {
    function dd($data = 0)
    {
        echo '<pre>';
        var_dump($data);
        exit();
    }
}
