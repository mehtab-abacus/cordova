<table width="700" border="0" style="margin: 0 auto; padding: 0; background: #e9ebee; width: 640px !important; min-width: 640px !important; font-family: sans-serif" cellpadding="0" cellspacing="0">
    <tr>
        <td style="vertical-align: top; padding: 20px 30px 10px;">
            <table width="100%">
                <tr>
                    <td style="vertical-align: middle;"><h2 style="margin: 0; padding: 0; color: #ed1c24;">MIBLOODLIFE</h2></td>
                    <td style="vertical-align: middle; text-align: right;">
                        <a href="https://chat.whatsapp.com/JrCZ0ft7wPO9yHOzGkOH5c" target="_blank"><img src="<?= base_url('assets/img/whatsapp.png') ?>" alt="" style="height: 32px;"></a>
                        <a href="https://www.facebook.com/faridabaddonorclub/" target="_blank"><img src="<?= base_url('assets/img/facebook.png') ?>" alt="" style="height: 28px;"></a>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="vertical-align: top; padding: 10px 30px 30px;">
            <div style="background: #fff; border-radius: 4px; padding:15px; border:solid 1px #ccc; border-top:0; border-bottom:0;">
                <p style="margin: 0; padding: 0; font-size: 14px; line-height: 24px; border-radius: 4px;">
                    <strong>Dear <?= $data->name ?>,</strong><br><br>
                    Thank you to be a part of this life saving application: MIBLOODLIFE.<br>
                    You are now a part of Faridabad Donors Club.<br><br>
                    Please verify your information below:
                </p>

                <p style="padding: 0; font-size: 14px; line-height: 28px; margin: 30px 0 0;">
                    <strong>Name: </strong> <?= $data->name ?><br>
                    <strong>Age: </strong> <?= $data->age ?><br>
                    <strong>Email: </strong> <?= $data->email ?><br>
                    <strong>Mobile: </strong> <?= $data->mobile ?><br>
                    <strong>Address: </strong> <?= $data->address ?><br>
                    <strong>Blood Group: </strong> <?= $data->blood_group ?><br>
                </p>

                <p style="padding: 0; font-size: 14px; margin: 30px 0 0;">In case your information is not correct, please refill the form on our app.<br>
                    For any queries please feel free to reply to this mail. Our team will get back to you ASAP.</p>
                <p style="padding: 0; font-size: 14px; line-height: 18px; margin: 30px 0 0;">
                    <strong>MIBLOODLIFE</strong><br>
                    <small>An Initiative of Faridabad Donors Club <br>
                        A Unit of Mahavir International Faridabad</small>
                </p>
            </div>
        </td>
    </tr>
    <tr>
        <td style="vertical-align: top; padding:3px 30px; background: #ed1c24;">
            <!--  -->
        </td>
    </tr>
</table>