<table width="700" border="0" style="margin: 0 auto; padding: 0; background: #e9ebee; width: 640px !important; min-width: 640px !important; font-family: sans-serif" cellpadding="0" cellspacing="0">
    <tr>
        <td style="vertical-align: top; padding: 20px 30px 10px;">
            <table width="100%">
                <tr>
                    <td style="vertical-align: middle;"><h2 style="margin: 0; padding: 0; color: #ed1c24;">MIBLOODLIFE</h2></td>
                    <td style="vertical-align: middle; text-align: right;">
                        <a href="https://chat.whatsapp.com/JrCZ0ft7wPO9yHOzGkOH5c" target="_blank"><img src="<?= base_url('assets/img/whatsapp.png') ?>" alt="" style="height: 32px;"></a>
                        <a href="https://www.facebook.com/faridabaddonorclub/" target="_blank"><img src="<?= base_url('assets/img/facebook.png') ?>" alt="" style="height: 28px;"></a>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="vertical-align: top; padding: 10px 30px 30px;">
            <div style="background: #fff; border-radius: 4px; padding:15px; border:solid 1px #ccc; border-top:0; border-bottom:0;">
                <p style="margin: 0; padding: 0; font-size: 14px; line-height: 24px; border-radius: 4px;">
                    <strong>Dear Umesh,</strong><br><br>
                    A new "Drive" request being raised at MIBLOODLIFE, Please follow:
                </p>

                <p style="padding: 0; font-size: 14px; line-height: 28px; margin: 30px 0 0;">
                    <strong>Name: </strong> <?= $data->name ?><br>
                    <strong>Organization: <?= $data->organization ?></strong> <br>
                    <strong>Address: </strong> <?= $data->address ?><br>
                    <strong>Drive Date: </strong> <?= date('d-m-Y', strtotime($data->drive_date)) ?><br>
                    <strong>Description: </strong> <?= $data->description ?><br>
                </p>

                <p style="padding: 0; font-size: 14px; line-height: 20px; margin: 30px 0 0;">
                    Thanks<br>
                    <strong>MIBLOODLIFE</strong>
                </p>
            </div>
        </td>
    </tr>
    <tr>
        <td style="vertical-align: top; padding:3px 30px; background: #ed1c24;">
            <!--  -->
        </td>
    </tr>
</table>