<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>MI BLOOD LIFE</title>

	<link type="text/css" rel="stylesheet" href="<?= base_url('assets/css/font-awesome.min.css') ?>" />
	<link type="text/css" rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>" />
</head>

<body>
	<div class="container">
		<p class="red">MI BLOOD</p>
		<p class="green">LIFE</p>
		<i class="fa fa-tint" aria-hidden="true"></i>
	</div>
</body>
</html>