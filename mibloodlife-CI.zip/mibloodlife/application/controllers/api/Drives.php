<?php defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');

class Drives extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('drive');
    }

    public function save()
    {
        if($this->input->server('REQUEST_METHOD') != 'POST') return $this->output->set_status_header(405);
        $driveId = $this->drive->save($this->input->post(), 'A');
        if($driveId) {
            $drive = $this->drive->getDrive($driveId);
            $this->drive->mailAdmin($drive);
            return $this->output->set_output(json_encode(['response' => true]));
        } return $this->output->set_output(json_encode(['response' => false]));
    }
}
