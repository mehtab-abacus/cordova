<?php defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');

class Donors extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('donor');
    }

    public function save()
    {
        if($this->input->server('REQUEST_METHOD') != 'POST') return $this->output->set_status_header(405);
        $donorId = $this->donor->save($this->input->post(), 'A');
        if($donorId) {
            $donor = $this->donor->getDonor($donorId);
            $this->donor->mailDonor($donor);
            $this->donor->mailAdmin($donor);
            return $this->output->set_output(json_encode(['response' => true]));
        } return $this->output->set_output(json_encode(['response' => false]));
    }
}
