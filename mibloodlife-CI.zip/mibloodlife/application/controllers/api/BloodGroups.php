<?php defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');

class BloodGroups extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('bloodGroup');
    }

    public function index()
    {
        $bloodGroups = $this->bloodGroup->getBloodGroups('A');
        return $this->output->set_output(json_encode(['blood_groups' => $bloodGroups]));
    }
}