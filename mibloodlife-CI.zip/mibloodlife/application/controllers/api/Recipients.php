<?php defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');

class Recipients extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('recipient');
    }

    public function save()
    {
        if($this->input->server('REQUEST_METHOD') != 'POST') return $this->output->set_status_header(405);
        $recipientId = $this->recipient->save($this->input->post(), 'A');
        if($recipientId) {
            $recipient = $this->recipient->getRecipient($recipientId);
            $this->recipient->mailRecipient($recipient);
            $this->recipient->mailAdmin($recipient);
            return $this->output->set_output(json_encode(['response' => true]));
        } return $this->output->set_output(json_encode(['response' => false]));
    }
}
