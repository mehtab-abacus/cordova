function saveDrive()
{
	$.ajax({
		type: 'POST',
		url: baseUrl + 'drives/save',
		data: $('#drive-form').serialize(),
		context: this,
		dataType: 'json',
		success: function(data, textStatus, xhr) {
			if(data.response) {
				window.location.href = 'index.html#successmsg';
				$('#processing').css('display', 'none');
			}
		},
		error: function(xhr, textStatus) {},
		beforeSend: function() {
			$('#processing').css('display', 'block');
		}
	});
	return false;
}

$("#drive-form").validate({
    focusInvalid: false,
    rules: {
        'name': {
            'required': true,
            'maxlength': 254
        },
        'organization': {
            'required': true,
            'maxlength': 254
        },
        'address': {
            'required': true,
            'maxlength': 254
        },
        'drive_date': {
            'required': true
        },
        'description': {
            'required': true
        }
    },
    submitHandler: function(form) {
        saveDrive();
    }
});

setDriveDate();
function setDriveDate()
{
    var min = new Date(), max = new Date();

    min.setDate(min.getDate() + 15);
    max.setDate(max.getDate() + 180);

    var min_dd = min.getDate();
    var min_mm = min.getMonth()+1;
    var min_yyyy = min.getFullYear();

    var max_dd = max.getDate();
    var max_mm = max.getMonth()+1;
    var max_yyyy = max.getFullYear();

    min_mm = (min_mm < 10) ? ("0" + min_mm) : min_mm;
    max_mm = (max_mm < 10) ? ("0" + max_mm) : max_mm;

    min = min_yyyy+'-'+min_mm+'-'+min_dd;
    max = max_yyyy+'-'+max_mm+'-'+max_dd;

    $('input[name="drive_date"]').attr({"min" : min, "max" : max});
}