function saveDonor()
{
	$.ajax({
		type: 'POST',
		url: baseUrl + 'donors/save',
		data: $('#donor-form').serialize(),
		context: this,
		dataType: 'json',
		success: function(data, textStatus, xhr) {
			if(data.response) {
				window.location.href = 'index.html#successmsg';
				$('#processing').css('display', 'none');
			}
		},
		error: function(xhr, textStatus) {},
		beforeSend: function() {
			$('#processing').css('display', 'block');
		}
	});
	return false;
}

$("#donor-form").validate({
    focusInvalid: false,
    rules: {
        'name': {
            'required': true,
            'maxlength': 254
        },
        'age': {
            'required': true,
            'min': 18,
            'max': 60
        },
        'blood_group': {
            'required': true
        },
        'mobile': {
            'required': true,
            'maxlength': 10
        },
        'email': {
            'required': true,
            'validEmail': true
        },
        'address': {
            'required': true,
            'maxlength': 254
        }
    },
    submitHandler: function(form) {
        saveDonor();
    }
});

jQuery.validator.addMethod("validEmail", function(value, element) {
    return (/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i.test(value));
}, "Please enter a valid email address.");