function saveRecipient()
{
	$.ajax({
		type: 'POST',
		url: baseUrl + 'recipients/save',
		data: $('#need-blood-form').serialize(),
		context: this,
		dataType: 'json',
		success: function(data, textStatus, xhr) {
			if(data.response) {
				window.location.href = 'index.html#successmsg';
				$('#processing').css('display', 'none');
			}
		},
		error: function(xhr, textStatus) {},
		beforeSend: function() {
			$('#processing').css('display', 'block');
		}
	});
	return false;
}

$("#need-blood-form").validate({
    focusInvalid: false,
    rules: {
        'name': {
            'required': true,
            'maxlength': 254
        },
        'age': {
            'required': true,
            'min': 1,
            'max': 110
        },
        'component': {
            'required': true
        },
        'blood_group': {
            'required': true
        },
        'units': {
            'required': true,
            'number': true
        },
        'mobile': {
            'required': true,
            'maxlength': 10
        },
        'email': {
            'required': true,
            'validEmail': true
        },
        'hospital': {
            'required': true,
            'maxlength': 254
        },
        'address': {
            'required': true,
            'maxlength': 254
        }
    },
    submitHandler: function(form) {
        saveRecipient();
    }
});

jQuery.validator.addMethod("validEmail", function(value, element) {
    return (/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i.test(value));
}, "Please enter a valid email address.");