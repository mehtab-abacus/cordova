loadBloodGroups();
function loadBloodGroups()
{
	$.ajax({
		type: 'GET',
		url: baseUrl + 'bloodGroups',
		data: '',
		context: this,
		dataType: 'json',
		success: function(data, textStatus, xhr) {
			renderBloodGroups(data.blood_groups);
		},
		error: function(xhr, textStatus) {},
		beforeSend: function() {}
	});
}

function renderBloodGroups(bloodGroups)
{
	$.each(bloodGroups, function(index, value) {
		$('select[name="blood_group"]').append('<option value="'+value.id+'">'+value.blood_group+'</option>');
	});
}